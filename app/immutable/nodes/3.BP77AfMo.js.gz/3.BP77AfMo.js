import{s as P,n as F}from"../chunks/scheduler.CUBAXF3E.js";import{S as G,i as U,k as $,s as f,e as v,l as h,f as p,c as g,a as D,d as l,m as w,g as d,h as C,n as _,o as b,p as y,q as E,r as S}from"../chunks/index.DMES01o0.js";import{M as N,P as I,a as A,b as L,S as R,c as k,N as M,d as V,F as W,e as O,f as j,A as B,g as q,h as H}from"../chunks/home.D9Im9A00.js";function K(T){let s,r,a,o="About Us",c,i,u,n,m=`<div class="h-8"></div> <img class="float-right ml-8 mb-8 relative right-0 rounded-lg sm:w-1/2 w-full" alt="banner" src="${B}"/> <div class="${O.light}">CLK Lion Dance and Kung Fu has been led by Sifu Sammy Cheng since 1990.

				<div class="h-8"></div>
				Since our inception, we&#39;ve performed hundreds of weddings and have travelled across Canada and
				the world to train, compete, and bring excitement to people&#39;s special events.

				<div class="h-8"></div>
				We specialize in Lion Dances for weddings, bringing good luck, fortune, and energy to crowds
				across Toronto. We&#39;ll provide a traditional performance with a modern flare.

				<div class="h-8"></div>
				Feed the lion, and if you are up for it, we can even invite you and your partner into the lion
				yourself mid-show, and you can show off your lion dance style, dancing and playing with your
				loved one&#39;s on your special day.

				<div class="h-8"></div>
				Our award winning team will customize for your unique occasion and bring a performance to remember.

				<div class="h-8"></div>
				Visit us at our martial arts club in Scarborough and see what we are all about. We&#39;d be honored
				to be part of your special event and will work closely with you to create a performance to remember!

				<div class="h-8"></div>
				See you soon!</div> <div class="h-8"></div> <div class="w-full flex flex-col sm:flex-row justify-evenly"><div class="sm:w-2/5 w-full"><img class="w-full rounded-lg" alt="about sifu" src="${q}"/></div> <div class="h-8 w-8"></div> <div class="sm:w-2/5 w-full"><img class="w-full rounded-lg" alt="about group" src="${H}"/></div></div>`;return{c(){s=v("div"),r=f(),a=v("div"),a.textContent=o,c=f(),i=v("br"),u=f(),n=v("div"),n.innerHTML=m,this.h()},l(e){s=g(e,"DIV",{class:!0}),D(s).forEach(l),r=p(e),a=g(e,"DIV",{class:!0,"data-svelte-h":!0}),E(a)!=="svelte-8uljab"&&(a.textContent=o),c=p(e),i=g(e,"BR",{}),u=p(e),n=g(e,"DIV",{class:!0,"data-svelte-h":!0}),E(n)!=="svelte-1nj4lk4"&&(n.innerHTML=m),this.h()},h(){S(s,"class","h-8"),S(a,"class",O.bold+" "+j["2xl"]),S(n,"class","inline-block")},m(e,t){d(e,s,t),d(e,r,t),d(e,a,t),d(e,c,t),d(e,i,t),d(e,u,t),d(e,n,t)},p:F,d(e){e&&(l(s),l(r),l(a),l(c),l(i),l(u),l(n))}}}function z(T){let s,r,a,o,c,i,u,n,m;return s=new N({props:{title:`About | ${I}`,description:A,canonical:L,nofollow:!1,noindex:!1,openGraph:{url:L,title:`About | ${I}`,description:A,site_name:R},twitter:{cardType:"summary_large_image",title:`About | ${I}`,description:A,image:`${k}/IMG-20230130-WA0025.jpg`,imageAlt:"CLK Lion Dance"}}}),o=new M({}),i=new V({props:{$$slots:{default:[K]},$$scope:{ctx:T}}}),n=new W({}),{c(){$(s.$$.fragment),r=f(),a=v("section"),$(o.$$.fragment),c=f(),$(i.$$.fragment),u=f(),$(n.$$.fragment)},l(e){h(s.$$.fragment,e),r=p(e),a=g(e,"SECTION",{});var t=D(a);h(o.$$.fragment,t),c=p(t),h(i.$$.fragment,t),u=p(t),h(n.$$.fragment,t),t.forEach(l)},m(e,t){w(s,e,t),d(e,r,t),d(e,a,t),w(o,a,null),C(a,c),w(i,a,null),C(a,u),w(n,a,null),m=!0},p(e,[t]){const x={};t&1&&(x.$$scope={dirty:t,ctx:e}),i.$set(x)},i(e){m||(_(s.$$.fragment,e),_(o.$$.fragment,e),_(i.$$.fragment,e),_(n.$$.fragment,e),m=!0)},o(e){b(s.$$.fragment,e),b(o.$$.fragment,e),b(i.$$.fragment,e),b(n.$$.fragment,e),m=!1},d(e){e&&(l(r),l(a)),y(s,e),y(o),y(i),y(n)}}}class X extends G{constructor(s){super(),U(this,s,null,z,P,{})}}export{X as component};
