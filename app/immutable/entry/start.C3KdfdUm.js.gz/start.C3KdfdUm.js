import{a as t}from"../chunks/entry.B-0N_T8n.js";export{t as start};
